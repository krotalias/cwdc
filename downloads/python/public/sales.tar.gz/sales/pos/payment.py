from typing import Protocol
from pos.order import Order
import asyncio
import random

class PaymentServiceConnectionError(Exception):
    """Custom error that is raised when we couldn't connect 
       the payment service."""

class OrderRepository(Protocol):
    def find_order(self, order_id: str) -> Order:
        ...

    def compute_order_total_price(self, order: Order) -> int:
        ...

class StripePaymentProcessor:
    """Payment processor via stripe."""

    def __init__(self, system: OrderRepository):
        self.connected = False
        self.system = system

    async def connect_to_service(self, url: str) -> None:
        """
        Asynchronous method for simmulating a connection to stripe.
        Arguments:
            @param url service to connect.
        @see https://realpython.com/async-io-python/
        """

        print(
            f"Connecting to payment processing service at {url}... ")

        await asyncio.sleep(random.randint(1, 10))

        print("done!")
        self.connected = True

    def process_payment(self, order_id: str) -> None:
        if not self.connected:
            raise PaymentServiceConnectionError()
        order = self.system.find_order(order_id)
        total_price = self.system.compute_order_total_price(order)
        print(
            f"Processing payment of ${(total_price / 100):.2f}, " +
            f"reference: {order.id}.")
