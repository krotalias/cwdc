#!/usr/bin/env python3

"""
Main function for the Point Of Sale system.

@author A smart guy.
@since 18/05/2022
@see https://www.forbes.com/advisor/business/software/point-of-sale/
"""


from pos.order import Order
from pos.system import POSSystem
import asyncio

async def main() -> None:
    # create the POSsystem and setup the payment processor
    system = POSSystem()
    await system.setup_payment_processor("https://api.stripe.com/v2")

    # create the order
    order = Order(
        1902,
        "Fluminense F. C.",
        "Rua Álvaro Chaves 41",
        "22231-220",
        "Rio de Janeiro",
        "atendimento@fluminense.com.br"
    )

    # price in cents
    order.create_line_item("camisas", 100, 200 * 100)
    order.create_line_item("bolas de futebol", 10, 70 * 100)
    order.create_line_item("chuteiras", 200, 1500 * 100)

    # register and process order
    system.register_order(order)
    system.process_order(order)


if __name__ == "__main__":
    import time
    s = time.perf_counter()
    asyncio.run(main())
    elapsed = time.perf_counter() - s
    file = __file__.split("/")[-1]
    print(f"\n{file} executed in {elapsed:0.2f} seconds.")
